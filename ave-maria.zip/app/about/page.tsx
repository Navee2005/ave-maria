import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-sky-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="font-serif text-3xl font-bold tracking-tighter sm:text-5xl text-sky-900">
                About Ave Maria
              </h1>
              <p className="max-w-[900px] text-slate-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-light">
                Our mission, vision, and the team behind our church media services.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission and Vision */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
        <div className="container px-4 md:px-6">
          <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
            <div>
              <div className="space-y-4">
                <div className="inline-block rounded-lg bg-sky-100 px-3 py-1 text-sm text-sky-700 font-medium">
                  Our Mission
                </div>
                <h2 className="font-serif text-3xl font-bold tracking-tighter sm:text-4xl text-sky-900">
                  Empowering Churches Through Media
                </h2>
                <p className="text-slate-600 md:text-xl/relaxed font-light">
                  Ave Maria exists to provide free, professional-quality media services to churches of all sizes,
                  helping them effectively communicate their message in today's digital world.
                </p>
                <p className="text-slate-600 md:text-xl/relaxed font-light">
                  We believe that every church deserves access to high-quality media resources regardless of their
                  budget or technical capabilities.
                </p>
              </div>
            </div>
            <div>
              <div className="space-y-4">
                <div className="inline-block rounded-lg bg-sky-100 px-3 py-1 text-sm text-sky-700 font-medium">
                  Our Vision
                </div>
                <h2 className="font-serif text-3xl font-bold tracking-tighter sm:text-4xl text-sky-900">
                  A World Where Every Church Can Thrive
                </h2>
                <p className="text-slate-600 md:text-xl/relaxed font-light">
                  We envision a world where every church has the tools and resources they need to effectively share
                  their message and connect with their community.
                </p>
                <p className="text-slate-600 md:text-xl/relaxed font-light">
                  By removing the financial barriers to professional media services, we help churches of all sizes reach
                  more people and make a greater impact in their communities.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-sky-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="font-serif text-3xl font-bold tracking-tighter sm:text-5xl text-sky-900">Meet Our Team</h2>
              <p className="max-w-[900px] text-slate-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-light">
                The dedicated professionals behind Ave Maria's mission.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-8 py-12 md:grid-cols-2 lg:grid-cols-3">
            <Card className="text-center border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader className="pb-0">
                <div className="flex justify-center">
                  <div className="relative h-40 w-40 rounded-full overflow-hidden border-4 border-sky-100">
                    <Image src="/placeholder.svg?height=160&width=160" alt="John Davis" fill className="object-cover" />
                  </div>
                </div>
                <CardTitle className="mt-4 font-serif text-sky-900">John Davis</CardTitle>
                <CardDescription>Founder & Executive Director</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 font-light">
                  Former church media director with 15 years of experience in video production and media ministry.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader className="pb-0">
                <div className="flex justify-center">
                  <div className="relative h-40 w-40 rounded-full overflow-hidden border-4 border-sky-100">
                    <Image
                      src="/placeholder.svg?height=160&width=160"
                      alt="Sarah Johnson"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
                <CardTitle className="mt-4 font-serif text-sky-900">Sarah Johnson</CardTitle>
                <CardDescription>Creative Director</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 font-light">
                  Award-winning designer with a passion for helping churches develop compelling visual identities.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader className="pb-0">
                <div className="flex justify-center">
                  <div className="relative h-40 w-40 rounded-full overflow-hidden border-4 border-sky-100">
                    <Image
                      src="/placeholder.svg?height=160&width=160"
                      alt="Michael Rodriguez"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
                <CardTitle className="mt-4 font-serif text-sky-900">Michael Rodriguez</CardTitle>
                <CardDescription>Lead Videographer</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 font-light">
                  Experienced filmmaker with a background in documentary and narrative storytelling.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-sky-700 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="font-serif text-3xl font-bold tracking-tighter sm:text-5xl">Join Our Mission</h2>
              <p className="max-w-[900px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-light">
                Help us provide free media services to more churches by donating or volunteering.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/donate">
                <Button size="lg" variant="secondary" className="px-8 bg-white text-sky-700 hover:bg-sky-50">
                  Donate Now
                </Button>
              </Link>
              <Link href="/contact">
                <Button size="lg" variant="outline" className="px-8 border-white text-white hover:bg-sky-600">
                  Contact Us <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

