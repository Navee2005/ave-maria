import type React from "react"
import { Playfair_Display, Inter } from "next/font/google"
import Link from "next/link"
import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"

import { ThemeProvider } from "@/components/theme-provider"
import { Button } from "@/components/ui/button"
import "./globals.css"

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
})

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
})

export const metadata = {
  title: "Ave Maria - Church Media Services",
  description: "Providing free professional media services to churches",
    generator: 'v0.dev'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${inter.variable} ${playfair.variable} font-sans`}>
        <ThemeProvider attribute="class" defaultTheme="light">
          <div className="flex flex-col min-h-screen">
            <header className="sticky top-0 z-50 w-full border-b border-sky-100 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
              <div className="container flex h-16 items-center">
                <Link href="/" className="flex items-center space-x-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6 text-sky-700"
                  >
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                  </svg>
                  <span className="font-serif text-lg font-semibold text-sky-900">Ave Maria</span>
                </Link>
                <nav className="ml-auto flex gap-4 sm:gap-6">
                  <Link
                    href="/"
                    className="text-sm font-medium text-slate-700 hover:text-sky-700 hover:underline underline-offset-4 transition-colors"
                  >
                    Home
                  </Link>
                  <Link
                    href="/portfolio"
                    className="text-sm font-medium text-slate-700 hover:text-sky-700 hover:underline underline-offset-4 transition-colors"
                  >
                    Portfolio
                  </Link>
                  <Link
                    href="/about"
                    className="text-sm font-medium text-slate-700 hover:text-sky-700 hover:underline underline-offset-4 transition-colors"
                  >
                    About Us
                  </Link>
                  <Link
                    href="/donate"
                    className="text-sm font-medium text-slate-700 hover:text-sky-700 hover:underline underline-offset-4 transition-colors"
                  >
                    Donate
                  </Link>
                  <Link
                    href="/contact"
                    className="text-sm font-medium text-slate-700 hover:text-sky-700 hover:underline underline-offset-4 transition-colors"
                  >
                    Contact
                  </Link>
                </nav>
                <div className="ml-4">
                  <Link href="/donate">
                    <Button size="sm" className="hidden sm:flex bg-sky-700 hover:bg-sky-800 transition-colors">
                      Donate Now
                    </Button>
                  </Link>
                </div>
              </div>
            </header>
            <main className="flex-1">{children}</main>
            <footer className="border-t border-sky-100 py-6 md:py-0 bg-sky-50">
              <div className="container flex flex-col gap-4 md:h-24 md:flex-row md:items-center">
                <div className="flex flex-1 items-center justify-center gap-4 md:justify-start">
                  <Link href="/" className="flex items-center space-x-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-sky-700"
                    >
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                    </svg>
                    <span className="font-serif text-sky-900 font-semibold">Ave Maria</span>
                  </Link>
                  <p className="text-sm text-slate-600">
                    &copy; {new Date().getFullYear()} Ave Maria. All rights reserved.
                  </p>
                </div>
                <div className="flex items-center justify-center gap-4 md:justify-end">
                  <Link
                    href="/privacy-policy"
                    className="text-sm text-slate-600 hover:text-sky-700 hover:underline underline-offset-4 transition-colors"
                  >
                    Privacy Policy
                  </Link>
                  <div className="flex items-center gap-2">
                    <Link href="#" className="text-slate-600 hover:text-sky-700 transition-colors">
                      <Facebook className="h-5 w-5" />
                      <span className="sr-only">Facebook</span>
                    </Link>
                    <Link href="#" className="text-slate-600 hover:text-sky-700 transition-colors">
                      <Instagram className="h-5 w-5" />
                      <span className="sr-only">Instagram</span>
                    </Link>
                    <Link href="#" className="text-slate-600 hover:text-sky-700 transition-colors">
                      <Twitter className="h-5 w-5" />
                      <span className="sr-only">Twitter</span>
                    </Link>
                    <Link href="#" className="text-slate-600 hover:text-sky-700 transition-colors">
                      <Youtube className="h-5 w-5" />
                      <span className="sr-only">YouTube</span>
                    </Link>
                  </div>
                </div>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'