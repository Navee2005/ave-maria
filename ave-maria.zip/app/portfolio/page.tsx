import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Video, Camera } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PortfolioPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-blue-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Our Portfolio</h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Browse our collection of media projects created for churches across the country.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Tabs */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="all">All Projects</TabsTrigger>
                <TabsTrigger value="video">Video Production</TabsTrigger>
                <TabsTrigger value="photography">Photography</TabsTrigger>
                <TabsTrigger value="design">Graphic Design</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="all" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Video Project 1 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Easter Service Video"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Video className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Easter Service Highlights</CardTitle>
                    <CardDescription>Grace Community Church</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      A cinematic highlight reel capturing the joy and celebration of Easter Sunday services.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>

                {/* Photography Project 1 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Church Architecture Photography"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Camera className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Sacred Spaces</CardTitle>
                    <CardDescription>St. Mary's Cathedral</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Architectural photography highlighting the beauty and craftsmanship of historic church buildings.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>

                {/* Design Project 1 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Church Branding Design"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-12 w-12 text-white"
                      >
                        <path d="M14 3v4a1 1 0 0 0 1 1h4" />
                        <path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2z" />
                        <path d="M12 17v-6" />
                        <path d="M9.5 14.5 12 17l2.5-2.5" />
                      </svg>
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Brand Identity</CardTitle>
                    <CardDescription>New Life Fellowship</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Complete brand identity package including logo, color palette, and marketing materials.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>

                {/* Video Project 2 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Church Promotional Video"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Video className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Community Outreach</CardTitle>
                    <CardDescription>Hope Fellowship</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Promotional video showcasing the church's community service initiatives and impact.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>

                {/* Photography Project 2 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Youth Group Event Photography"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Camera className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Youth Retreat</CardTitle>
                    <CardDescription>Faith Community Church</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Event photography capturing meaningful moments from the annual youth retreat.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>

                {/* Design Project 2 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Church Social Media Graphics"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-12 w-12 text-white"
                      >
                        <path d="M14 3v4a1 1 0 0 0 1 1h4" />
                        <path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2z" />
                        <path d="M12 17v-6" />
                        <path d="M9.5 14.5 12 17l2.5-2.5" />
                      </svg>
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Social Media Campaign</CardTitle>
                    <CardDescription>Trinity Church</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Cohesive social media graphics package for sermon series and church events.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="video" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Video Project 1 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Easter Service Video"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Video className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Easter Service Highlights</CardTitle>
                    <CardDescription>Grace Community Church</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      A cinematic highlight reel capturing the joy and celebration of Easter Sunday services.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>

                {/* Video Project 2 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Church Promotional Video"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Video className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Community Outreach</CardTitle>
                    <CardDescription>Hope Fellowship</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Promotional video showcasing the church's community service initiatives and impact.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="photography" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Photography Project 1 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Church Architecture Photography"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Camera className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Sacred Spaces</CardTitle>
                    <CardDescription>St. Mary's Cathedral</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Architectural photography highlighting the beauty and craftsmanship of historic church buildings.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>

                {/* Photography Project 2 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Youth Group Event Photography"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Camera className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Youth Retreat</CardTitle>
                    <CardDescription>Faith Community Church</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Event photography capturing meaningful moments from the annual youth retreat.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="design" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Design Project 1 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Church Branding Design"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-12 w-12 text-white"
                      >
                        <path d="M14 3v4a1 1 0 0 0 1 1h4" />
                        <path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2z" />
                        <path d="M12 17v-6" />
                        <path d="M9.5 14.5 12 17l2.5-2.5" />
                      </svg>
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Brand Identity</CardTitle>
                    <CardDescription>New Life Fellowship</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Complete brand identity package including logo, color palette, and marketing materials.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>

                {/* Design Project 2 */}
                <Card>
                  <div className="relative aspect-video overflow-hidden rounded-t-lg">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Church Social Media Graphics"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-12 w-12 text-white"
                      >
                        <path d="M14 3v4a1 1 0 0 0 1 1h4" />
                        <path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2z" />
                        <path d="M12 17v-6" />
                        <path d="M9.5 14.5 12 17l2.5-2.5" />
                      </svg>
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle>Social Media Campaign</CardTitle>
                    <CardDescription>Trinity Church</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Cohesive social media graphics package for sermon series and church events.
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" size="sm" className="w-full">
                      View Project
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Call to Action */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Need Media Services?</h2>
              <p className="max-w-[900px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                We provide free professional media services to churches. Get in touch to discuss your project.
              </p>
            </div>
            <Link href="/contact">
              <Button size="lg" variant="secondary" className="px-8">
                Contact Us <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

