import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Heart, Church, Camera, Video, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-b from-sky-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="font-serif text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-sky-900">
                  Empowering Churches Through Media
                </h1>
                <p className="max-w-[600px] text-slate-700 md:text-xl font-light">
                  Ave Maria provides free professional media services to help churches spread their message effectively.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/donate">
                  <Button className="px-8 bg-sky-700 hover:bg-sky-800">Donate Now</Button>
                </Link>
                <Link href="/portfolio">
                  <Button variant="outline" className="px-8 text-sky-700 border-sky-200 hover:bg-sky-50">
                    View Our Work
                  </Button>
                </Link>
              </div>
            </div>
            <div className="relative h-[300px] md:h-[400px] lg:h-[500px] rounded-xl overflow-hidden shadow-lg">
              <Image
                src="/placeholder.svg?height=500&width=800"
                alt="Church service with modern media"
                fill
                className="object-cover"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      {/* Impact Statistics */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="font-serif text-3xl font-bold tracking-tighter sm:text-5xl text-sky-900">Our Impact</h2>
              <p className="max-w-[900px] text-slate-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-light">
                See how Ave Maria is making a difference in church communities across the nation.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3">
            <Card className="text-center border-sky-100 shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-center">
                  <Church className="h-12 w-12 text-sky-600" />
                </div>
                <CardTitle className="text-4xl font-bold text-sky-900">250+</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">Churches Served</p>
              </CardContent>
            </Card>
            <Card className="text-center border-sky-100 shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-center">
                  <Video className="h-12 w-12 text-sky-600" />
                </div>
                <CardTitle className="text-4xl font-bold text-sky-900">1,000+</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">Media Projects Completed</p>
              </CardContent>
            </Card>
            <Card className="text-center border-sky-100 shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-center">
                  <Users className="h-12 w-12 text-sky-600" />
                </div>
                <CardTitle className="text-4xl font-bold text-sky-900">50,000+</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">People Reached</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-sky-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="font-serif text-3xl font-bold tracking-tighter sm:text-5xl text-sky-900">Testimonials</h2>
              <p className="max-w-[900px] text-slate-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-light">
                Hear from the churches we've helped with our media services.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
            <Card className="border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="font-serif text-sky-900">Grace Community Church</CardTitle>
                <CardDescription>Pastor Michael Johnson</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 italic">
                  "Ave Maria transformed our online presence. Their professional videos and graphics have helped us
                  reach more people than ever before."
                </p>
              </CardContent>
            </Card>
            <Card className="border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="font-serif text-sky-900">St. Mary's Parish</CardTitle>
                <CardDescription>Father Thomas Williams</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 italic">
                  "The quality of work Ave Maria provides is outstanding. We could never afford these services
                  otherwise."
                </p>
              </CardContent>
            </Card>
            <Card className="border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="font-serif text-sky-900">New Life Fellowship</CardTitle>
                <CardDescription>Pastor Sarah Davis</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 italic">
                  "Their team understood our vision and created media that perfectly represents our church's mission and
                  values."
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-sky-700 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="font-serif text-3xl font-bold tracking-tighter sm:text-5xl">Support Our Mission</h2>
              <p className="max-w-[900px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-light">
                Your donation helps us provide free media services to churches in need.
              </p>
            </div>
            <Link href="/donate">
              <Button size="lg" variant="secondary" className="px-8 bg-white text-sky-700 hover:bg-sky-50">
                Donate Now <Heart className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="font-serif text-3xl font-bold tracking-tighter sm:text-5xl text-sky-900">Our Services</h2>
              <p className="max-w-[900px] text-slate-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-light">
                Professional media services we offer to churches at no cost.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
            <Card className="border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-center">
                  <Video className="h-12 w-12 text-sky-600" />
                </div>
                <CardTitle className="text-center font-serif text-sky-900">Video Production</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-slate-600">
                  Professional video services for sermons, events, and promotional content.
                </p>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Link href="/portfolio?category=video">
                  <Button variant="outline" size="sm" className="text-sky-700 border-sky-200 hover:bg-sky-50">
                    View Examples <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
            <Card className="border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-center">
                  <Camera className="h-12 w-12 text-sky-600" />
                </div>
                <CardTitle className="text-center font-serif text-sky-900">Photography</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-slate-600">
                  High-quality photography for events, staff portraits, and church facilities.
                </p>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Link href="/portfolio?category=photography">
                  <Button variant="outline" size="sm" className="text-sky-700 border-sky-200 hover:bg-sky-50">
                    View Examples <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
            <Card className="border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-12 w-12 text-sky-600"
                  >
                    <path d="M14 3v4a1 1 0 0 0 1 1h4" />
                    <path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2z" />
                    <path d="M12 17v-6" />
                    <path d="M9.5 14.5 12 17l2.5-2.5" />
                  </svg>
                </div>
                <CardTitle className="text-center font-serif text-sky-900">Graphic Design</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-slate-600">
                  Custom graphics for social media, bulletins, banners, and promotional materials.
                </p>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Link href="/portfolio?category=design">
                  <Button variant="outline" size="sm" className="text-sky-700 border-sky-200 hover:bg-sky-50">
                    View Examples <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}

