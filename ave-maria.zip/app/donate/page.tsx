import Link from "next/link"
import { Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DonatePage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-sky-50 to-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="font-serif text-3xl font-bold tracking-tighter sm:text-5xl text-sky-900">
                Support Our Mission
              </h1>
              <p className="max-w-[900px] text-slate-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed font-light">
                Your donation helps us provide free media services to churches in need.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Donation Options */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-3xl">
            <Tabs defaultValue="one-time" className="w-full">
              <div className="flex justify-center mb-8">
                <TabsList className="bg-sky-100">
                  <TabsTrigger
                    value="one-time"
                    className="data-[state=active]:bg-sky-700 data-[state=active]:text-white"
                  >
                    One-Time Donation
                  </TabsTrigger>
                  <TabsTrigger
                    value="monthly"
                    className="data-[state=active]:bg-sky-700 data-[state=active]:text-white"
                  >
                    Monthly Giving
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="one-time" className="space-y-8">
                <div className="grid gap-6">
                  <div className="space-y-2">
                    <h2 className="text-2xl font-bold font-serif text-sky-900">Make a One-Time Donation</h2>
                    <p className="text-slate-600 font-light">
                      Your generous gift will help us provide free media services to churches.
                    </p>
                  </div>

                  <form className="space-y-6">
                    <div className="space-y-4">
                      <Label className="text-slate-700">Select Amount</Label>
                      <RadioGroup defaultValue="50" className="grid grid-cols-3 gap-4">
                        <div>
                          <RadioGroupItem value="25" id="amount-25" className="peer sr-only" />
                          <Label
                            htmlFor="amount-25"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-sky-100 bg-white p-4 hover:bg-sky-50 hover:border-sky-200 peer-data-[state=checked]:border-sky-700 [&:has([data-state=checked])]:border-sky-700 transition-colors"
                          >
                            <span className="text-xl font-bold text-sky-900">$25</span>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem value="50" id="amount-50" className="peer sr-only" />
                          <Label
                            htmlFor="amount-50"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-sky-100 bg-white p-4 hover:bg-sky-50 hover:border-sky-200 peer-data-[state=checked]:border-sky-700 [&:has([data-state=checked])]:border-sky-700 transition-colors"
                          >
                            <span className="text-xl font-bold text-sky-900">$50</span>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem value="100" id="amount-100" className="peer sr-only" />
                          <Label
                            htmlFor="amount-100"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-sky-100 bg-white p-4 hover:bg-sky-50 hover:border-sky-200 peer-data-[state=checked]:border-sky-700 [&:has([data-state=checked])]:border-sky-700 transition-colors"
                          >
                            <span className="text-xl font-bold text-sky-900">$100</span>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem value="250" id="amount-250" className="peer sr-only" />
                          <Label
                            htmlFor="amount-250"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-sky-100 bg-white p-4 hover:bg-sky-50 hover:border-sky-200 peer-data-[state=checked]:border-sky-700 [&:has([data-state=checked])]:border-sky-700 transition-colors"
                          >
                            <span className="text-xl font-bold text-sky-900">$250</span>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem value="500" id="amount-500" className="peer sr-only" />
                          <Label
                            htmlFor="amount-500"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-sky-100 bg-white p-4 hover:bg-sky-50 hover:border-sky-200 peer-data-[state=checked]:border-sky-700 [&:has([data-state=checked])]:border-sky-700 transition-colors"
                          >
                            <span className="text-xl font-bold text-sky-900">$500</span>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem value="custom" id="amount-custom" className="peer sr-only" />
                          <Label
                            htmlFor="amount-custom"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-sky-100 bg-white p-4 hover:bg-sky-50 hover:border-sky-200 peer-data-[state=checked]:border-sky-700 [&:has([data-state=checked])]:border-sky-700 transition-colors"
                          >
                            <span className="text-xl font-bold text-sky-900">Custom</span>
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="custom-amount" className="text-slate-700">
                        Custom Amount
                      </Label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">$</span>
                        <Input
                          id="custom-amount"
                          type="number"
                          placeholder="Enter amount"
                          className="pl-8 border-sky-100 focus:border-sky-300 focus:ring-sky-300"
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="first-name" className="text-slate-700">
                            First Name
                          </Label>
                          <Input
                            id="first-name"
                            required
                            className="border-sky-100 focus:border-sky-300 focus:ring-sky-300"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="last-name" className="text-slate-700">
                            Last Name
                          </Label>
                          <Input
                            id="last-name"
                            required
                            className="border-sky-100 focus:border-sky-300 focus:ring-sky-300"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-slate-700">
                          Email Address
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          required
                          className="border-sky-100 focus:border-sky-300 focus:ring-sky-300"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-slate-700">
                          Phone Number (Optional)
                        </Label>
                        <Input
                          id="phone"
                          type="tel"
                          className="border-sky-100 focus:border-sky-300 focus:ring-sky-300"
                        />
                      </div>
                    </div>

                    <Button type="submit" className="w-full bg-sky-700 hover:bg-sky-800 transition-colors">
                      Donate Now
                    </Button>

                    <p className="text-xs text-center text-slate-500">
                      By donating, you agree to our{" "}
                      <Link href="/terms" className="text-sky-700 underline underline-offset-2 hover:text-sky-800">
                        Terms & Conditions
                      </Link>
                      . Donations are tax-deductible.
                    </p>
                  </form>
                </div>
              </TabsContent>

              <TabsContent value="monthly" className="space-y-8">
                <div className="grid gap-6">
                  <div className="space-y-2">
                    <h2 className="text-2xl font-bold font-serif text-sky-900">Become a Monthly Supporter</h2>
                    <p className="text-slate-600 font-light">
                      Your recurring gift provides sustainable support for our mission.
                    </p>
                  </div>

                  <div className="grid gap-6 md:grid-cols-3">
                    <Card className="text-center border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <CardTitle className="font-serif text-sky-900">Friend</CardTitle>
                        <div className="text-3xl font-bold text-sky-700">$10</div>
                        <CardDescription>per month</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center">
                            <Check className="mr-2 h-4 w-4 text-sky-600" />
                            <span className="text-slate-600">Monthly newsletter</span>
                          </li>
                          <li className="flex items-center">
                            <Check className="mr-2 h-4 w-4 text-sky-600" />
                            <span className="text-slate-600">Name on donor wall</span>
                          </li>
                        </ul>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full bg-sky-700 hover:bg-sky-800 transition-colors">Select</Button>
                      </CardFooter>
                    </Card>

                    <Card className="text-center border-sky-700 bg-white shadow-md hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <CardTitle className="font-serif text-sky-900">Partner</CardTitle>
                        <div className="text-3xl font-bold text-sky-700">$25</div>
                        <CardDescription>per month</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center">
                            <Check className="mr-2 h-4 w-4 text-sky-600" />
                            <span className="text-slate-600">Monthly newsletter</span>
                          </li>
                          <li className="flex items-center">
                            <Check className="mr-2 h-4 w-4 text-sky-600" />
                            <span className="text-slate-600">Name on donor wall</span>
                          </li>
                          <li className="flex items-center">
                            <Check className="mr-2 h-4 w-4 text-sky-600" />
                            <span className="text-slate-600">Annual impact report</span>
                          </li>
                        </ul>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full bg-sky-700 hover:bg-sky-800 transition-colors">Select</Button>
                      </CardFooter>
                    </Card>

                    <Card className="text-center border-sky-100 bg-white shadow-md hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <CardTitle className="font-serif text-sky-900">Champion</CardTitle>
                        <div className="text-3xl font-bold text-sky-700">$50</div>
                        <CardDescription>per month</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center">
                            <Check className="mr-2 h-4 w-4 text-sky-600" />
                            <span className="text-slate-600">Monthly newsletter</span>
                          </li>
                          <li className="flex items-center">
                            <Check className="mr-2 h-4 w-4 text-sky-600" />
                            <span className="text-slate-600">Name on donor wall</span>
                          </li>
                          <li className="flex items-center">
                            <Check className="mr-2 h-4 w-4 text-sky-600" />
                            <span className="text-slate-600">Annual impact report</span>
                          </li>
                          <li className="flex items-center">
                            <Check className="mr-2 h-4 w-4 text-sky-600" />
                            <span className="text-slate-600">Exclusive updates</span>
                          </li>
                        </ul>
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full bg-sky-700 hover:bg-sky-800 transition-colors">Select</Button>
                      </CardFooter>
                    </Card>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>
    </div>
  )
}

